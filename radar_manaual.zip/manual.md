本Wiki配有视频教程: **[http://www.riskengine.cn](http://www.riskengine.cn)**  
## 1. 安装（适用于版本v1.0.6）
    git clone https://gitee.com/freshday/radar.git
    mvn clean install 

## 2. 配置

### 2.1 数据库
    CREATE DATABASE IF NOT EXISTS radar DEFAULT CHARSET utf8mb4;
    # 初始化数据库
    source radar-init.sql
    source radar-1.0.6.sql
    source radar-1.0.7.sql
    source radar-1.0.8.sql 

### 2.2 中间件
   项目启动还需要安装 redis 、 mongodb、elasticsearch    
   windows 安装程序可以通过我的百度网盘下载,   
   链接：https://pan.baidu.com/s/1C-UdV71tAa6n07ZNo_EvVw 
   提取码：q3p4  

   或者通过docker 方式安装

```
// redis
docker pull redis:3.2
docker run --name redis3.2 -p 6379:6379  -d redis:3.2 redis-server --appendonly yes
    
// mongo
docker pull mongo:4.0.13-xenial
docker run --name mongo4.0 -p 27017:27017 -d mongo:4.0.13-xenial
    
// es
docker pull elasticsearch:6.8.7
docker run -d --name es6.8  -p 9200:9200 -p 9300:9300 -e "discovery.type=single-node"  --restart=always  elasticsearch:6.8.7
```
V1.0.4后 es 升级到了7.6.X 
```
docker run -d --name es7.6  -p 9200:9200 -p 9300:9300 -e "discovery.type=single-node"  --restart=always  elasticsearch:7.6.1
```

### 2.3 应用配置
两个启动项目的application.yml 都需要进行修改, 除了mysql配置外，在启动前还需要配置如下几个必要的选项：mongodb,redis, 
手机号码段文件， ip地址库, 依赖资源见上面的百度网盘  
```
mongodb:
  url: mongodb://localhost:27017/radar   //mongodb 
mobile:
  info:
    path: D:/soft/moble_info.csv        //手机号码段信息
ip2region:
  db:
    path: D:/soft/ip2region.db          // IP地址库 
```



## 3. 启动
    # 运行服务端 
    cd radar-admin 
    java -jar radar-admin.jar
    # 运行引擎端
    cd radar-engine
    java -jar radar-engine.jar 

管理端入口：http://localhost:6580   
默认用户：admin/123456  

引擎端入口：http://localhost:6581

## 4. 模型配置
### 新建模型
初次熟悉系统的时候建议选择使用  **模板**  创建模型。
![主页](https://images.gitee.com/uploads/images/2019/1014/235326_c6826c09_5150633.png)
### 字段管理
查看刚才新建模型的字段，通过修改和增加调整模型。
![字段管理](https://images.gitee.com/uploads/images/2019/1014/235325_532232f7_5150633.png)
### 预处理字段
系统自带一些插件用来对原始字段转换处理。
![字段管理](https://images.gitee.com/uploads/images/2019/1014/235325_a2f251e5_5150633.png)
### 特征处理
定义我们需要关心的指标。
![字段管理](https://images.gitee.com/uploads/images/2019/1014/235325_0df82f70_5150633.png)
![字段管理](https://images.gitee.com/uploads/images/2019/1014/235325_83af0239_5150633.png)
### Activation 策略集管理
整个风险的量化过程就在这里，模型的输出点，组合若干条特征，综合计分，通常定义两个分数线，一个是审核线（低分数表示需要人工审核，
一个拒绝线，表示此交易可以直接拒绝） 
![规则管理](https://images.gitee.com/uploads/images/2019/1014/235325_ff50729e_5150633.png)
![规则管理](https://images.gitee.com/uploads/images/2019/1014/235327_841b5490_5150633.png)
### 构建模型
点击构建模型，Mongodb,ES将会为模型创建索引信息
![构建模型](https://images.gitee.com/uploads/images/2019/1014/235327_510bcb97_5150633.png)

### 模型激活
最后一定要点击激活按钮，大功告成！
![模型激活](https://images.gitee.com/uploads/images/2019/1023/155143_9df95260_5150633.png "模型激活")  
模型建立好了，赶紧测试一下吧！   **[测试模型](https://gitee.com/freshday/radar/wikis/test?sort_id=1637447)** 