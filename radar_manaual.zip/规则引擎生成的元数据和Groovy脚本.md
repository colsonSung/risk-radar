
通过管理平台配置的规则，会生成两种信息，一种用于前端页面显示的元信息，一种是用于groovy 脚本，用于运行时，分别如下：  
```
"ruleDefinition": {
	"linking": "All",
	"conditions": [{
		"class": "SMPL",
		"expressions": [{
			"column": "abstractions.tran_ip_1_hour_qty",
			"type": "DOUBLE",
			"class": "ENTATTR"
		}, {
			"type": "DOUBLE",
			"class": "CONST",
			"value": "15"
		}],
		"enabled": true,
		"operator": "Greater_Equal"
	}],
	"class": "PDCT",
	"enabled": true
}
```

```
class ActivationCheckScript {  
    public boolean check(def data, def lists) {    
        if (data.abstractions.tran_ip_1_hour_qty>=15)       
         return true;   
         else        
            return false;
    }
}
```