## 介绍 
一款基于java语言，使用Springboot + Mongodb + Groovy + ES 等框架搭建的轻量级实时风控引擎，适用于反欺诈应用场景，开箱即用。


## 引擎处理流程
![流程图](https://images.gitee.com/uploads/images/2019/1015/000636_fecd15c8_5150633.jpeg "引擎处理流程图")

## 数据ER关系图
![radar_er](https://images.gitee.com/uploads/images/2019/1015/164225_b90f6a4d_5150633.png "radar_er")

## Demo数据
以ting提现为例：
![guid](https://images.gitee.com/uploads/images/2019/1105/172609_572c5612_5150633.png "model_id.png")
数据样例： 
```
modelGuid : DB8A078F-97FE-4A7F-AAC0-5AF1A6C36CE8
reqId: 100005
jsonInfo: {
        "eventId":"100005", "mobile":"18516249909", "userId":"18516249909",
        "eventTime":1576035291628, "userIP":"180.175.166.148", 
        "deviceId": "SDKSKDSLD-ASDFA-32348235", "os":"ios","amount":500.0,
        "channel":"alipay"
        }   
```
 
响应样例：
```
{
    "success": true,
    "msg": "",
    "code": "100",
    "data": {},
    "abstractions": { // 特征 指标的计算结果，方便大家调试和核对
        "tran_did_1_day_qty": 2,
        "tran_did_ip_1_day_qty": 0,
        "tran_uid_ip_1_day_qty": 1,
        "tran_uid_1_hour_amt": 1000.0,
        "tran_ip_1_hour_qty": 2,
        "tran_ip_1_day_amt": 1000.0,
        "tran_ip_10_min_amt": 1000.0,
        "tran_ip_1_hour_amt": 1000.0,
        "tran_uid_1_day_amt": 1000.0,
        "tran_did_10_min_qty": 2,
        "tran_did_1_hour_qty": 2,
        "tran_ip_1_day_qty": 2,
        "tran_ip_10_min_qty": 2,
        "tran_uid_10_min_amt": 1000.0
    },
    "adaptations": null,
    "activations": {
        "transaction_exception": {
            "risk": "reject", // 风险级别：pass 通过， reject 拒绝， review 人工审核
            "score": 120  //风险积分
        }
    },
    "hitsDetail": { // 具体命中的规则项
        "transaction_exception": [
            {
                "key": "381",
                "value": 120.0,
                "desc": "1天内IP交易金额大于1000"
            }
        ]
    },
    "respTimes": { // 各模块耗时情况
        "adaptations": 0,
        "activations": 2,
        "abstractions": 27
    }
}
```
## [使用手册](https://gitee.com/freshday/radar/wikis/manual?sort_id=1637446)
https://gitee.com/freshday/radar/wikis/manual?sort_id=1637446 