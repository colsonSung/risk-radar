## 风控EngineAPI
项目采用Swagger做API文档管理，进行测试前请确认模型已经进行过   **构建模型  模型激活**   
URL: [engine api](http://localhost:6581/swagger-ui.html) http://localhost:6581/swagger-ui.html
![API DOC](https://foruda.gitee.com/images/1660460661427736176/upload-api.jpeg "upload-api.jpg")
 
提交事件获取风险打分，通过POST + JSON 的方式提交数据，注意参数说明  
modelGuid : model guid 可以通过管理控制台界面查看  
reqId ： 请求流水号  
jsonInfo： 事件具体json信息  
![guid](https://images.gitee.com/uploads/images/2019/1105/172310_18ec2cb2_5150633.png "model_id.png")
![事件提交](https://images.gitee.com/uploads/images/2019/1015/001123_5707f116_5150633.png)

请求数据样例： 
建议使用 RequestBody
```
{
"guid" : "DB8A078F-97FE-4A7F-AAC0-5AF1A6C36CE8",
"reqId": 100001,
"jsonInfo": {
        "eventId":"100001", "mobile":"18516249909", "userId":"18516249909",
        "eventTime":1672924515000, "userIP":"180.175.166.148", 
        "deviceId": "SDKSKDSLD-ASDFA-32348235", "os":"ios","amount":509.0,
        "channel":"alipay"
        }   
}
```

或者使用请求参数: 
```
modelGuid : DB8A078F-97FE-4A7F-AAC0-5AF1A6C36CE8
reqId: 100005
jsonInfo: {
        "eventId":"100005", "mobile":"18516249909", "userId":"18516249909",
        "eventTime":1672924515000, "userIP":"180.175.166.148", 
        "deviceId": "SDKSKDSLD-ASDFA-32348235", "os":"ios","amount":500.0,
        "channel":"alipay"
        }   
```


 
响应样例：
```
{
    "success": true,
    "msg": "",
    "code": "100",
    "data": {},
    "abstractions": { // 特征 指标的计算结果，方便大家调试和核对
        "tran_did_1_day_qty": 2,
        "tran_did_ip_1_day_qty": 0,
        "tran_uid_ip_1_day_qty": 1,
        "tran_uid_1_hour_amt": 1000.0,
        "tran_ip_1_hour_qty": 2,
        "tran_ip_1_day_amt": 1000.0,
        "tran_ip_10_min_amt": 1000.0,
        "tran_ip_1_hour_amt": 1000.0,
        "tran_uid_1_day_amt": 1000.0,
        "tran_did_10_min_qty": 2,
        "tran_did_1_hour_qty": 2,
        "tran_ip_1_day_qty": 2,
        "tran_ip_10_min_qty": 2,
        "tran_uid_10_min_amt": 1000.0
    },
    "adaptations": null,
    "activations": {
        "transaction_exception": {
            "risk": "reject", // 风险级别：pass 通过， reject 拒绝， review 人工审核
            "score": 120  //风险积分
        }
    },
    "hitsDetail": { // 具体命中的规则项
        "transaction_exception": [
            {
                "key": "381",
                "value": 120.0,
                "desc": "1天内IP交易金额大于1000"
            }
        ]
    },
    "respTimes": { // 各模块耗时情况
        "adaptations": 0,
        "activations": 2,
        "abstractions": 27
    }
}
```