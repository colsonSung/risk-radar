### v1.0.6
    1.经纬度转换成行政区域
    2.HTTP插件支持多参数
    3.前端支持系统黑白黑白名单
    4.规则命中图标支持时间过滤

### v1.0.4
    1. mongodb的访问方式升级为 SpringData。
    2. elasticsearch 升级为7.X 使用 high level api 访问。
    3. 集成 mapstruts， 提升对象copy 性能。
    4. 配置文件拆解，支持多环境配置
    5. kafka集成radar Demo

### v1.0.3
    docker 镜像的编写， 需要包含 mysql, redis, mongodb, es 等中间件。
    data list record 导入功能 前端部分
    增加 ES 中间件，提供数据查询，规则命中统计报表等功能
    机器学习支持, 主流机器学习框架的API集成，用于已经训练好的模型调用 （TensorFlow）。
![规则命中查询](https://images.gitee.com/uploads/images/2020/0314/180216_73b1450e_5150633.jpeg "规则命中查询")

### v1.0.2
    列表数据导入   
    Rest 工具 插件（通过Http获取其它关联数据）  

### v1.0.1
    React 版本升级（v15.0.0） 
    集成 JWT(JSON WEB TOKEN)，前后端分离标准化  
    日期格式化插件 