## 数据库
创建数据库，并导入数据到本地mysql数据库，数据库文件见 resources目录  
 
    CREATE DATABASE IF NOT EXISTS radar DEFAULT CHARSET utf8 COLLATE utf8_general_ci;
    # 初始化数据库
    source radar-init.sql
    srouce radar-1.0.6.sql


## 安装 docker
直接官网下载：https://www.docker.com/products/docker-desktop
![输入图片说明](https://images.gitee.com/uploads/images/2019/1212/200044_8ffb98db_5150633.png "docker-version.png")

## 镜像下载
链接：https://pan.baidu.com/s/1C-UdV71tAa6n07ZNo_EvVw
提取码：q3p4 
下载  _**docker-radar.zip**_ , 然后解压修改application.yml 配置文件，替换   **mysql**  数据库url，用户名，密码等数据库信息。

## 启动镜像
```
docker-compose up -d
```
如图：
 
![输入图片说明](https://images.gitee.com/uploads/images/2019/1212/195753_d8c4fa60_5150633.png "docker-radar-start.png")

## 访问入口
管理端：http://localhost:6580/

引擎端：http://localhost:6581/


## docker-compose.yml

```
version: '2' 
services:
  admin:  
    build: ./admin
    image: radar-admin:1.0.3
    ports:    
      - "6580:6580"
    links:
      - "redis:redis"
      - "mongo:mongo"
  engine:  
    image: radar-engine:1.0.3
    build: ./engine  
    ports:    
      - "6581:6581"
    links:
      - "redis:redis"
      - "mongo:mongo"
  redis:
    image: redis:3.2
  mongo:
    image: mongo:4.0.13-xenial
```
