### 本地测试，不使用任何特征提取功能，测试纯规则下的性能情况   
#### 规则配置
![6条规则](https://images.gitee.com/uploads/images/2021/0323/151351_4ae443ef_5150633.png "6条规则.png")
#### 测试结果
![100并发](https://images.gitee.com/uploads/images/2021/0323/151006_e97cfab1_5150633.png "100并发.png")